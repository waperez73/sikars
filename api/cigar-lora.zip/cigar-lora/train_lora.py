from diffusers import StableDiffusionPipeline, DDPMScheduler
from peft import LoraConfig, get_peft_model
from transformers import AutoTokenizer
from datasets import load_dataset
import torch

# Base Stable Diffusion
model_id = "stabilityai/stable-diffusion-2-1"
pipe = StableDiffusionPipeline.from_pretrained(
    model_id, torch_dtype=torch.float16
).to("cuda")

# LoRA config (lightweight adapter)
lora_config = LoraConfig(
    r=16,             # rank (smaller = lighter)
    lora_alpha=32,    # scaling
    target_modules=["to_q", "to_v"],  # attention layers
    lora_dropout=0.1,
    bias="none"
)

# Attach LoRA to UNet
pipe.unet = get_peft_model(pipe.unet, lora_config)

# Dataset: expects folder of images
dataset = load_dataset("imagefolder", data_dir="data/robusto")

# Training params
epochs = 3
lr = 1e-4
batch_size = 2

optimizer = torch.optim.AdamW(pipe.unet.parameters(), lr=lr)

for epoch in range(epochs):
    for step, example in enumerate(dataset["train"]):
        img = example["image"].convert("RGB").resize((512, 512))
        inputs = pipe.feature_extractor(img, return_tensors="pt").pixel_values.to("cuda")
        
        # dummy prompt — during real training you provide captions
        captions = ["a photo of a skrobusto cigar"]
        enc = pipe.tokenizer(captions, return_tensors="pt", padding=True, truncation=True).to("cuda")

        loss = pipe.unet(inputs, enc.input_ids).loss
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        if step % 10 == 0:
            print(f"Epoch {epoch} Step {step}: Loss {loss.item()}")

pipe.save_pretrained("output/skrobusto-lora")
