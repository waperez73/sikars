from diffusers import StableDiffusionPipeline
from peft import PeftModel
import torch

pipe = StableDiffusionPipeline.from_pretrained(
    "stabilityai/stable-diffusion-2-1", torch_dtype=torch.float16
).to("cuda")

pipe.unet = PeftModel.from_pretrained(pipe.unet, "output/skrobusto-lora")

prompt = "A luxury wooden cigar box with 10 skrobusto cigars, engraved Joe Doe by sikars.com"
image = pipe(prompt).images[0]
image.save("preview.png")
